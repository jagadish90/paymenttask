import { Component, OnInit } from "@angular/core";
import { ServiceService } from "../service/service.service";

@Component({
  selector: "app-register",
  templateUrl: "./register.component.html",
  styleUrls: ["./register.component.css"]
})
export class RegisterComponent implements OnInit {
  logout: any;
  model: any = {};

  constructor(private service: ServiceService) {}

  register(form) {
    console.log(form);
    this.service.register(form).subscribe(data => {});
  }

  ngOnInit() {}
}
