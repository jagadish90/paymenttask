import { Component, OnInit } from "@angular/core";
import { ServiceService } from '../service/service.service';
@Component({
  selector: "app-dashboard",
  templateUrl: "./dashboard.component.html",
  styleUrls: ["./dashboard.component.css"]
})
export class DashboardComponent implements OnInit {
  balance: any;
  usersemail: any = [];
  recenttransacions: any = [];
  constructor(private service: ServiceService) {}

  getusers() {
    var email = localStorage.getItem("email");
    this.service.getusers(email).subscribe(data => {
      console.log(data);
      this.usersemail = data;
    });
  }

  sendamount(sendform) {
    // console.log(typeof(this.balance),typeof (sendform.amount));
    if (parseInt(this.balance) >= parseInt(sendform.amount)) {
      var email = localStorage.getItem("email");
      var d = new Date();
      var date = d.getDate() + "/" + d.getMonth() + "/" + d.getFullYear();
      sendform.email = email;
      sendform.date = date;

      this.service.sendamount(sendform).subscribe(data => {
        console.log("succes");
        this.getbalance();
      });
    } else {
      alert("balance is low");
    }
  }

  getbalance() {
    var email = localStorage.getItem("email");

    this.service.getbalance(email).subscribe(data => {
      // console.log(data);
      if (data.length > 0) {
        this.balance = data[0].amount;
      } else {
        this.balance = 0;
      }
    });
  }
  ngOnInit() {
    var email = localStorage.getItem("email");

    this.service.recentttransactions(email).subscribe(data => {
      console.log(data);
      this.recenttransacions = data;
    });

    this.getbalance();
  }
}
