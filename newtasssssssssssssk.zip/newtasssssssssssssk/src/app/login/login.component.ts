import { Component, OnInit } from '@angular/core';
import {ServiceService} from '../service/service.service';
import { Router } from '../../../node_modules/@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private service:ServiceService, private router:Router) { }

  login(form){
    // console.log(form);
    this.service.login(form).subscribe(data=>{
      console.log(data);
      if(data.length>0){
        
        this.router.navigate(['dashboard']);
        localStorage.setItem('email',data[0].email);
      }
      else{
        alert('Invaid Login')
      }
    })
    
  }
  ngOnInit() {
  }

}
