import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "../../../node_modules/rxjs";

@Injectable({
  providedIn: "root"
})
export class ServiceService {
  api = "http://localhost:4600";
  constructor(private http: HttpClient) {}

  register(form): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({ "content-type": "application/json" })
    };

    return this.http.post(this.api + "/register", form, httpOptions);
  }
  login(form): Observable<any> {
    return this.http.post(this.api + "/login", form);
  }
  recentttransactions(email):Observable<any>{
    return this.http.get(this.api+'/recentttransactions/'+email);
  }
  
  getbalance(email):Observable<any>{
    return this.http.get(this.api+'/getbalance/'+email)
  }
  getusers(email):Observable<any>{
    return this.http.get(this.api+'/getallusers/'+email);
  }
  sendamount(form):Observable<any>{
    const httpOptions = { headers: new HttpHeaders({'content-type':'application/json'})};
    return this.http.post(this.api+'/postsenddata',form,httpOptions)
  }
  }

